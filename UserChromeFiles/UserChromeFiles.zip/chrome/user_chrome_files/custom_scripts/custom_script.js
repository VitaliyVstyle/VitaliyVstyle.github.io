// This script can be used, for example, to create buttons using CustomizableUI.createWidget
