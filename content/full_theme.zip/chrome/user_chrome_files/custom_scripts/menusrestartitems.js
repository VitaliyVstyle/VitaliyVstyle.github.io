(async (
    id = Symbol("menusrestartitems"),
    btnID = "ucf-appmenu-restart-button",
    muimID = "ucf_menu_FileRestartItem",
) => (this[id] = {
    init() {
        var abtn = document.querySelector("template#appMenu-viewCache")?.content.querySelector("#appMenu-quit-button2");
        if (abtn) {
            let frag = MozXULElement.parseXULToFragment(`<toolbarbutton/>`);
            let btn = this.btn = frag.firstElementChild;
            btn.id = btnID;
            btn.className = "subviewbutton";
            btn.setAttribute("label", "Перезапуск");
            btn.setAttribute("tooltiptext", "ЛКМ: Перезапустить приложение\nСКМ: Перезапустить без дополнений\nПКМ: Перезапустить и заново создать кэш быстрого запуска");
            btn.setAttribute("shortcut", "Ctrl+Alt+Q");
            btn.addEventListener("click", this);
            abtn.before(frag);
        }
        var aftermuim = document.querySelector("#menu_FilePopup #menu_FileQuitItem");
        if (aftermuim) {
            let muim = this.muim = document.createXULElement("menuitem");
            muim.id = muimID;
            muim.className = "menuitem-iconic";
            muim.setAttribute("label", "Перезапуск");
            muim.setAttribute("tooltiptext", "ЛКМ: Перезапустить приложение\nСКМ: Перезапустить без дополнений\nПКМ: Перезапустить и заново создать кэш быстрого запуска");
            muim.setAttribute("acceltext", "Ctrl+Alt+Q");
            muim.setAttribute("context", "");
            muim.addEventListener("click", this);
            aftermuim.before(muim);
        }
        var style = "data:text/css;charset=utf-8," + encodeURIComponent(`
            #${btnID}, #${muimID} {
                list-style-image: url("chrome://global/skin/icons/reload.svg") !important;
                -moz-context-properties: fill;
                fill: color-mix(in srgb, currentColor 20%, #f38525) !important;
            }
        `);
        try {
            windowUtils.loadSheetUsingURIString(style, windowUtils.USER_SHEET);
        } catch (e) {}
        window.addEventListener("keydown", this);
        setUnloadMap(id, this.destructor, this);
    },
    click(e) {
        switch (e.button) {
            case 0:
                this._restart_mozilla();
                break;
            case 1:
                e.view.safeModeRestart();
                break;
            case 2:
                this._restart_mozilla(true);
                break;
        }
    },
    keydown(e) {
        if (e.code == "KeyQ" && e.ctrlKey && e.altKey)
            this._restart_mozilla();
    },
    _restart_mozilla(nocache = false) {
        var cancelQuit = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
        Services.obs.notifyObservers(cancelQuit, "quit-application-requested", "restart");
        if (cancelQuit.data)
            return false;
        if (nocache)
            Services.appinfo.invalidateCachesOnRestart();
        var {startup} = Services;
        startup.quit(startup.eAttemptQuit | startup.eRestart);
    },
    handleEvent(e) {
        this[e.type](e);
    },
    destructor() {
        window.removeEventListener("keydown", this);
        this.btn?.removeEventListener("click", this);
        this.muim?.removeEventListener("click", this);
    },
}).init())();
