// Этот скрипт работает в главном окне браузера если включено в настройках

var ucf_custom_script_win = {
    initialized: false,
    unloadlisteners: [],
    load: function() {
        if (this.initialized)
            return;
        this.initialized = true;
        // this.specialwidgets.init(); // <-- Special Widgets
        this.autohidesidebar.init(); // <-- Auto Hide Sidebar
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше

        /* ************************************************ */
        if (!this.unloadlisteners.length)
            return;
        window.addEventListener("unload", this, { once: true });
    },
    handleEvent: function(e) {
        this[e.type](e);
    },
    unload: function() {
        this.unloadlisteners.forEach(str => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
    specialwidgets: {
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in CustomizableUI)
                return this.Customizable = CustomizableUI;
            var scope = null;
            try {
                scope = Cu.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        init: function() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            ucf_custom_script_win.unloadlisteners.push("specialwidgets");
            window.addEventListener("customizationready", this);
        },
        destructor: function() {
            window.removeEventListener("customizationready", this);
        },
        handleEvent: function(e) {
            this[e.type](e);
        },
        customizationchange: function() {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this.createSpecialWidgets();
            }, 1000);
        },
        customizationready: function() {
            if (!this.Customizable)
                return;
            this.createSpecialWidgets();
            window.addEventListener("customizationchange", this);
            window.addEventListener("customizationending", this);
        },
        customizationending: function() {
            window.removeEventListener("customizationchange", this);
            window.removeEventListener("customizationending", this);
        },
        createSpecialWidgets: function() {
            try {
                let fragment = document.createDocumentFragment();
                if (this.findSpecialWidgets("spring")) {
                    let spring = this.Customizable.createSpecialWidget("spring", document);
                    spring.setAttribute("label", "Растягивающийся интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                }
                if (this.findSpecialWidgets("spacer")) {
                    let spacer = this.Customizable.createSpecialWidget("spacer", document);
                    spacer.setAttribute("label", "Интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                }
                if (this.findSpecialWidgets("separator")) {
                    let separator = this.Customizable.createSpecialWidget("separator", document);
                    separator.setAttribute("label", "Разделитель");
                    fragment.append(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                }
                gCustomizeMode.visiblePalette.append(fragment);
            } catch (e) {}
        },
        findSpecialWidgets: function(string) {
            try {
                if (!gCustomizeMode.visiblePalette.querySelector(`toolbar${string}[id^="customizableui-special-${string}"]`))
                    return true;
            } catch (e) {}
            return false;
        }
    },
    autohidesidebar: {
        sidebar: null,
        init: function() {
            var sidebar = this.sidebar = document.querySelector("#sidebar-box");
            if(!sidebar)
                return;
            ["dragenter", "drop", "dragexit"].forEach(type => {
                sidebar.addEventListener(type, this);
            });
            ucf_custom_script_win.unloadlisteners.push("autohidesidebar");
        },
        destructor: function() {
            var sidebar = this.sidebar;
            ["dragenter", "drop", "dragexit"].forEach(type => {
                sidebar.removeEventListener(type, this);
            });
        },
        handleEvent: function(e) {
            this[e.type](e);
        },
        dragenter: function() {
            if (!this.sidebar.hasAttribute("sidebardrag"))
                this.sidebar.setAttribute("sidebardrag", "true");
        },
        drop: function() {
            if (this.sidebar.hasAttribute("sidebardrag"))
                this.sidebar.removeAttribute("sidebardrag");
        },
        dragexit: function(e) {
            var sidebar = this.sidebar;
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!e.relatedTarget || e.screenY <= (boxScrn.screenY + 5) || e.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || e.screenX <= (boxScrn.screenX + 5) || e.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    },
    setattributechromemargin: {
        init: function() {
            if (AppConstants.platform != "win" || !(window.matchMedia("(-moz-os-version: windows-win8)").matches || window.matchMedia("(-moz-os-version: windows-win7)").matches)) return;
            if (TabsInTitlebar.enabled)
                document.documentElement.setAttribute("chromemargin", "0,7,7,7");
            TabsInTitlebar._update = eval(`(${`${TabsInTitlebar._update}`
                .replace(/setAttribute\s*\(\s*"\s*chromemargin\s*"\s*,\s*"\s*0\s*,\s*2\s*,\s*2\s*,\s*2\s*"\s*\)/, 'setAttribute("chromemargin", "0,7,7,7")')
                .replace(/^_update/, "function _update")})`);
        },
    },
    observerthemesync: {
        init() {
            window.addEventListener("windowlwthemeupdate", this);
            ucf_custom_script_win.unloadlisteners.push("observerthemesync");
        },
        handleEvent(e) {
            var docElm = document.documentElement,
            func_by_prefs = {
                "0true"() {
                    if (docElm.matches(":-moz-lwtheme-brighttext"))
                        Services.prefs.setIntPref("ui.systemUsesDarkTheme", 1);
                },
                "0false"() {
                    Services.prefs.clearUserPref("ui.systemUsesDarkTheme");
                },
                "1true"() {
                    if (!docElm.matches(":-moz-lwtheme-brighttext"))
                        Services.prefs.setIntPref("ui.systemUsesDarkTheme", 0);
                },
                "1false"() {
                    Services.prefs.clearUserPref("ui.systemUsesDarkTheme");
                },
                "2true"() {
                    Services.prefs.setIntPref("ui.systemUsesDarkTheme", docElm.matches(":-moz-lwtheme-brighttext") ? 1 : 0);
                },
                "2false"() {},
            };
            (func_by_prefs[`${Services.prefs.getIntPref("ui.systemUsesDarkTheme", 2)}${docElm.matches(":-moz-lwtheme")}`] || func_by_prefs["2true"])();
        },
        destructor() {
            window.removeEventListener("windowlwthemeupdate", this);
        },
    },
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        ucf_custom_script_win.load();
    }, { once: true });
} else
    ucf_custom_script_win.load();

ucf_custom_script_win.observerthemesync.init();
ucf_custom_script_win.setattributechromemargin.init();
