// Script For documents of all windows [ChromeOnly]
