/**
@UCF @param {"prop":"JsChrome.DOMContentLoaded","ucfobj":true} @UCF
*/
(async (
    SHOWDELAY = 300,
    HIDEDELAY = 2000,
) => ({
    isVisible: false,
    isMouseOver: false,
    showTimer: null,
    hideTimer: null,
    eventListeners: new Map(),
    init() {
        var menubar = this.menubar = document.querySelector("#toolbar-menubar > #menubar-items > #main-menubar");
        if (!menubar) return;
        var origitems = menubar.parentElement;
        var tool_menubar = this.tool_menubar = origitems.parentElement;
        var items = this.items = document.createElementNS("http://www.w3.org/1999/xhtml", "html:div");
        origitems.before(items);
        items.append(menubar);
        origitems.remove();
        items.id = "menubar-items";
        var popover = document.querySelector("div#urlbar[popover]");
        setUnloadMap(Symbol("appbutton"), this.destructor, this);
        if (popover) this.addListener("urlbar_toggle", popover, "toggle", this);
        else this.toggle({ newState: "open" });
        this.addListener("items_mouseenter", items, "mouseenter", this);
        this.addListener("items_mouseleave", items, "mouseleave", this);
        this.addListener("items_dragenter", items, "dragenter", this);
        this.addListener("items_mouseup", items, "mouseup", this);
        this.autohidechange = new MutationObserver(() => this.toggle({ newState: "open" }));
        this.autohidechange.observe(tool_menubar, {
            attributeFilter: ["autohide"],
            attributes: true,
        });
    },
    toggle(e, { items } = this) {
        items.removeAttribute("popover");
        if (e.newState === "open" && this.tool_menubar.hasAttribute("autohide") && this.tool_menubar.getAttribute("autohide") !== "false") {
            items.setAttribute("popover", "manual");
            items.showPopover();
        }
    },
    handleEvent(e) {
        this[e.type](e);
    },
    mouseenter({ currentTarget, target }) {
        switch (currentTarget) {
            case this.items:
                if (currentTarget != target) return;
                this.isMouseOver = true;
                if (!this.isVisible) this.showBar();
                break;
            default:
                this.isMouseOver = false;
                this.hideBar();
                break;
        }
    },
    mouseleave() {
        clearTimeout(this.showTimer);
    },
    dragenter({ target }) {
        switch (target) {
            case this.items:
                if (!this.isVisible) this.showBar();
                break;
        }
    },
    showBar(nodelay) {
        clearTimeout(this.showTimer);
        var onTimeout = () => {
            this.isVisible = true;
            this.items.setAttribute("menubar_visible", "true");
            var tabpanels = this.tabpanels ||= gBrowser.tabpanels;
            this.addListener("tabpanels_mouseenter", tabpanels, "mouseenter", this);
            this.addListener("tabpanels_mouseup", tabpanels, "mouseup", this);
        };
        if (!nodelay) this.showTimer = setTimeout(onTimeout, SHOWDELAY);
        else onTimeout();
    },
    hideBar(nodelay) {
        clearTimeout(this.hideTimer);
        var onTimeout = () => {
            if (this.isMouseOver) return;
            this.delListener("tabpanels_mouseenter");
            this.delListener("tabpanels_mouseup");
            this.items.setAttribute("menubar_visible", "false");
            this.isVisible = false;
        };
        if (!nodelay) this.hideTimer = setTimeout(onTimeout, HIDEDELAY);
        else onTimeout();
    },
    mouseup({ currentTarget, target, detail }) {
        switch (currentTarget) {
            case this.items:
                if (currentTarget != target || !detail) return;
                if (!this.isVisible) this.showBar(true);
                else {
                    this.isMouseOver = false;
                    this.hideBar(true);
                }
                break;
            default:
                this.hideBar(true);
                break;
        }
    },
    delListener(key) {
        var { eventListeners } = this, getkey = eventListeners.get(key);
        if (!getkey) return;
        var { elm, type, listener } = getkey;
        elm.removeEventListener(type, listener);
        eventListeners.delete(key);
    },
    addListener(key, elm, type, listener) {
        elm.addEventListener(type, listener);
        this.eventListeners.set(key, { elm, type, listener });
    },
    destructor() {
        this.eventListeners.forEach(({ elm, type, listener }) => elm.removeEventListener(type, listener));
        this.autohidechange.disconnect();
    },
}).init())();
