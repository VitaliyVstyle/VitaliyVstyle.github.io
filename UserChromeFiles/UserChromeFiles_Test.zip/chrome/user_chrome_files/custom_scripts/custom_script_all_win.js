/**
@UCF @param {"prop":"scriptsallchrome.load","ucfobj":true,"urlregxp":"^chrome:\\/\\/browser\\/content\\/(?:browser|places\\/(?:bookmarksSidebar|historySidebar|places)|sidebar\\/sidebar-history)\\.x?html","disable":true} @UCF
*/
